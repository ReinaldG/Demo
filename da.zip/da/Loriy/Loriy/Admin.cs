﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Loriy
{
    public partial class Admin : Form
    {
        public Admin()
        {
            InitializeComponent();
        }

        private void Back_Click(object sender, EventArgs e)
        {
            Form fauto = new Form1();
            fauto.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form fadmsotr = new AdmSotr();
            fadmsotr.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form fadmtask = new Admtask();
            fadmtask.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form fadmsm = new AdmSm();
            fadmsm.Show();
        }
    }
}
