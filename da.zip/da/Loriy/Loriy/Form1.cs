﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Loriy
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form f1 = new PasAndLog();
            f1.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text)|| string.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("Введите логин и пароль");
                return;
            }

            using (var db = new Loriy_UchEntities())
            {
                var user = db.Autoreg
                    .AsNoTracking()
                    .FirstOrDefault(u => u.login == textBox1.Text && u.password == textBox2.Text);


                if (user == null)
                {
                    MessageBox.Show("Тебя нет, найдись, опробуй ссылку просмотра логинов и паролей");
                    return;
                }

                    switch (user.role)
                    {
                        case "админ":
                            Form fadm = new Admin();
                            fadm.Show();
                            break;

                        case "водитель":
                            Form fvod = new Vod();
                            fvod.Show();
                            break;

                        case "менеджер":
                            Form fmened = new Mened();
                            fmened.Show();
                            break;
                    }
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            panel1.Visible = true;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form fadm = new Admin();
            fadm.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form fvod = new Vod();
            fvod.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form fmened = new Mened();
            fmened.Show();
            this.Hide();
        }
    }
}
